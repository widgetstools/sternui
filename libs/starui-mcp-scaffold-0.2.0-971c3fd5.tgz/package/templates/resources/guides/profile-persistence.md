# Profile persistence

MarketsGrid profiles persist via `withStorage` + `ConfigManager`:

- **Key:** `(appId, userId, instanceId, gridId)`
- **Storage:** localStorage (browser) or ConfigService (OpenFin)
- **Export:** customizer → grid-state module → snapshot

Use `starui_profile_recipe` for a starter bundle JSON shape.
