# @starui/mcp-scaffold

**StarUI Platform MCP** — one package for scaffolding external-consumer apps, wiring STOMP data providers, diagnosing empty grids, OpenFin routes, design compliance, and tarball management.

## Run

```bash
# From npm (when published)
npx -y @starui/mcp-scaffold

# From monorepo tarball
npx -y ./libs/starui-mcp-scaffold-0.2.0-<sha>.tgz
```

## Install in Cursor / Claude Code

```json
{
  "mcpServers": {
    "starui-platform": {
      "command": "npx",
      "args": ["-y", "@starui/mcp-scaffold"],
      "env": { "STARUI_ROOT": "/path/to/starui" }
    }
  }
}
```

Set `STARUI_ROOT` to your monorepo checkout so `starui_refresh_libs` can propagate fresh tarballs.

## Common questions

| Question | Tool / resource |
|----------|-----------------|
| Why is my grid empty? | `starui_diagnose_data_plane` · `starui://troubleshooting/empty-grid` |
| How do I wire STOMP? | `starui_setup_stomp_dev` · `starui_generate_stomp_config` · `starui://guides/wire-stomp` |

## Tool groups (38 tools)

**Scaffold & templates:** `starui_list_templates`, `starui_recommend_template`, `starui_scaffold_app`, `starui_upgrade_scaffold`

**Grid:** `starui_list_grid_features`, `starui_explain_grid_feature`, `starui_suggest_grid_features`, `starui_add_grid_module`, `starui_generate_column_defs`, `starui_profile_recipe`

**Data providers & STOMP:** `starui_list_provider_types`, `starui_generate_stomp_config`, `starui_validate_provider_config`, `starui_add_provider_to_project`, `starui_setup_stomp_dev`, `starui_test_stomp_connection`, `starui_diagnose_data_plane`, `starui_explain_provider_toolbar`, `starui_provider_config_from_csv`

**Tarballs:** `starui_check_tarball_versions`, `starui_refresh_libs`, `starui_explain_import_alias`, `starui_bucket_dependency_graph`

**OpenFin:** `starui_explain_component_registration`, `starui_add_blotter_route`, `starui_generate_view_manifest`, `starui_openfin_launch_checklist`

**Design & UI:** `starui_list_ui_components`, `starui_add_ui_component`, `starui_audit_app_design`, `starui_add_shell_layout`, `starui_theme_playground_snippet`, `starui_shadcn_component_picker`, `starui_validate_design_compliance`

**Testing:** `starui_validate_scaffold`, `starui_smoke_test_app`, `starui_validate_stomp_e2e`, `starui_snapshot_grid_config`

**Meta:** `starui_print_install_config`

## MCP resources

- `starui://design-rules`
- `starui://guides/stomp-marketsgrid`
- `starui://guides/wire-stomp`
- `starui://troubleshooting/empty-grid`
- `starui://recipes/provider-stomp-positions`
- `starui://recipes/openfin-blotter-route`

## Pack

From repo root: `npm run pack:mcp`
