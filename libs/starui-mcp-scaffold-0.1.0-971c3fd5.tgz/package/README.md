# @starui/mcp-scaffold

MCP server for scaffolding external-consumer StarUI React apps.

## Run

```bash
# From npm (when published)
npx -y @starui/mcp-scaffold

# From monorepo tarball
npx -y ./libs/starui-mcp-scaffold-0.1.0-<sha>.tgz
```

## Install in Cursor / Claude Code

```json
{
  "mcpServers": {
    "starui-scaffold": {
      "command": "npx",
      "args": ["-y", "@starui/mcp-scaffold"],
      "env": { "STARUI_ROOT": "/path/to/starui" }
    }
  }
}
```

## Install in VS Code (`.vscode/mcp.json`)

```json
{
  "servers": {
    "starui-scaffold": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@starui/mcp-scaffold"]
    }
  }
}
```

## Tools

| Tool | Description |
|------|-------------|
| `starui_list_templates` | Five scaffold templates |
| `starui_list_grid_features` | MarketsGrid feature picker |
| `starui_list_ui_components` | @starui/ui shadcn catalog |
| `starui_scaffold_app` | Create app with bundled `libs/` tarballs |
| `starui_add_ui_component` | Add shadcn UI recipe |
| `starui_validate_design_compliance` | Token + shadcn linter |
| `starui_print_install_config` | IDE config snippets |

## Pack

From repo root: `npm run pack:mcp`
