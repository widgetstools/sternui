/**
 * TemplateManager — unified "saved templates" surface used by both
 * the in-grid FormattingToolbar's template popover AND the popped-out
 * FormattingPropertiesPanel's Templates section.
 *
 * UX (redesigned 2026-05-03):
 *   ┌────────────────────────────────────────┐
 *   │  Bold              [✏] [⟳] [🗑]        │ ← rows; click body = apply,
 *   │ ✓ Currency         [✏] [⟳] [🗑]        │   actions hover-revealed
 *   │  …                                      │
 *   ├────────────────────────────────────────┤
 *   │  Save current as: [name…]      [+]     │
 *   ├────────────────────────────────────────┤
 *   │  Will save: Styles · Formatter · Filter │ ← "what's in the snapshot" hint
 *   └────────────────────────────────────────┘
 *
 * The per-row UPDATE button lets users re-snapshot the active column
 * INTO an existing template — the user-requested "save additional
 * settings to an existing template" affordance. RENAME swaps the row
 * label into an inline input. DELETE uses a two-step confirm
 * (mousedown-to-arm, click-to-commit) to defeat single-misclick
 * destruction.
 *
 * One implementation powers both surfaces via `variant`:
 *   - `compact`  — toolbar popover (~320px, denser rows)
 *   - `panel`    — popped-out properties panel (full-width)
 */

import { useEffect, useRef, useState } from 'react';
import { Pencil, Plus, RotateCw, Trash2, Check, X } from 'lucide-react';
import { GhostIconButton, Input } from '@starui/grid/customizer';
import { Button, cn } from '@starui/ui';

// Inactive-row hover tint. Co-located here (instead of marketsGrid.css)
// so the row + its buttons stay self-contained — the row also serves
// as `data-row-hover-target` for the GhostIconButton reveal, so its
// hover feedback is part of the same primitive's behaviour. Idempotent
// + SSR-safe per the same pattern GhostIconButton uses.
const ROW_STYLE_ID = 'ds-tpl-row-styles';
if (typeof document !== 'undefined' && !document.getElementById(ROW_STYLE_ID)) {
  const style = document.createElement('style');
  style.id = ROW_STYLE_ID;
  style.textContent = `
    .ds-tpl-row:not([data-active='true']):hover {
      background: color-mix(in srgb, var(--ds-text-primary) 5%, transparent) !important;
    }
  `;
  document.head.appendChild(style);
}

export interface TemplateManagerProps {
  templates: ReadonlyArray<{ id: string; name: string }>;
  activeTemplateId?: string;
  disabled?: boolean;

  // Save-as — controlled input (owner decides where the draft lives).
  saveName: string;
  saveConfirmed: boolean;
  onSaveNameChange: (value: string) => void;
  onSave: () => void;

  onApply: (id: string) => void;
  onDelete: (id: string) => void;

  /** Re-snapshot the active column and overwrite an existing template.
   *  Omit to hide the per-row Update affordance. */
  onUpdate?: (id: string) => void;
  /** Rename an existing template inline. Omit to hide the per-row
   *  Rename affordance. Implementations should call the formatter's
   *  `renameTemplate(id, newName)` action. */
  onRename?: (id: string, name: string) => void;

  /**
   * Optional human-readable list of template categories the active
   * column can currently save (e.g. `['Styles', 'Formatter', 'Filter']`).
   * Renders as a small caption beneath the save row so users know
   * what the snapshot will capture BEFORE clicking save. Empty array
   * => the column has nothing template-eligible.
   */
  capturableFields?: ReadonlyArray<string>;

  /** Layout variant. `compact` = popover inside toolbar (320px,
   *  tighter spacing); `panel` = full-width Section inside the
   *  popped-out Properties panel. */
  variant?: 'compact' | 'panel';

  /** Optional test-id prefix applied to interactive elements so E2E
   *  can assert on the same primitive regardless of variant. */
  testIdPrefix?: string;
}

interface RowProps {
  id: string;
  name: string;
  isActive: boolean;
  isRenaming: boolean;
  renameDraft: string;
  pendingDeleteId: string | null;
  disabled: boolean;
  hasUpdate: boolean;
  hasRename: boolean;
  onApply: () => void;
  onUpdate: () => void;
  onStartRename: () => void;
  onCommitRename: () => void;
  onCancelRename: () => void;
  onRenameDraftChange: (v: string) => void;
  onArmDelete: () => void;
  onConfirmDelete: () => void;
  testId: string;
}

function TemplateRow({
  id,
  name,
  isActive,
  isRenaming,
  renameDraft,
  pendingDeleteId,
  disabled,
  hasUpdate,
  hasRename,
  onApply,
  onUpdate,
  onStartRename,
  onCommitRename,
  onCancelRename,
  onRenameDraftChange,
  onArmDelete,
  onConfirmDelete,
  testId,
}: RowProps) {
  const isPendingDelete = pendingDeleteId === id;

  return (
    <Button
      type="button"
      variant="ghost"
      disabled={disabled}
      data-testid={testId}
      data-row-hover-target=""
      data-active={isActive ? 'true' : undefined}
      className={cn(
        'ds-tpl-row relative flex h-[30px] w-full items-center gap-1.5 rounded-[2px] px-2.5 py-0',
        'shadow-none hover:bg-transparent focus-visible:ring-0',
        isActive && 'bg-[color-mix(in_srgb,var(--ds-primary)_10%,transparent)]',
      )}
      tabIndex={isRenaming ? -1 : 0}
      onClick={() => { if (!isRenaming && !isPendingDelete) onApply(); }}
      style={{
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.5 : 1,
        transition: 'background 120ms',
      }}
    >
      {/* Active accent bar */}
      <span
        aria-hidden
        style={{
          position: 'absolute', left: 2, top: 6, bottom: 6,
          width: 2, borderRadius: 2,
          background: isActive ? 'var(--ds-primary)' : 'transparent',
        }}
      />

      {/* Leading check / dot */}
      <span className="inline-flex items-center justify-center w-3 h-3 shrink-0">
        {isActive ? (
          <Check size={11} strokeWidth={2.5} className="text-[var(--ds-primary)]" />
        ) : (
          <span className="w-[5px] h-[5px] rounded-full bg-[color-mix(in_srgb,var(--ds-text-muted)_50%,transparent)]" />
        )}
      </span>

      {/* Name — switches to input while renaming */}
      {isRenaming ? (
        <Input
          type="text"
          value={renameDraft}
          autoFocus
          data-testid={`${testId}-rename-input`}
          onClick={(e) => e.stopPropagation()}
          onChange={(e) => onRenameDraftChange(e.target.value)}
          onKeyDown={(e) => {
            e.stopPropagation();
            if (e.key === 'Enter') { e.preventDefault(); onCommitRename(); }
            else if (e.key === 'Escape') { e.preventDefault(); onCancelRename(); }
          }}
          onBlur={onCommitRename}
          className="flex-1 min-w-0 h-[22px] px-1.5 text-[11px] shadow-none focus-visible:ring-0"
          style={{
            background: 'var(--ds-surface-ground)',
            border: '1px solid color-mix(in srgb, var(--ds-primary) 55%, var(--ds-border-primary))',
            borderRadius: 2,
            color: 'var(--ds-text-primary)',
            fontSize: 11,
            fontWeight: isActive ? 600 : 450,
            outline: 'none',
          }}
        />
      ) : (
        <span style={{
          flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
          fontSize: 11,
          fontWeight: isActive ? 600 : 450,
          color: 'var(--ds-text-primary)',
          letterSpacing: 0.1,
        }}>
          {name}
        </span>
      )}

      {/* Action buttons — hover-revealed via GhostIconButton's
          `reveal="on-row-hover"` (the row sets `data-row-hover-target`).
          The pending-delete + renaming branches force `revealed` so
          actions stay visible while a multi-step flow is in progress. */}
      {!isRenaming && (
        <>
          {hasUpdate && (
            <GhostIconButton
              reveal="on-row-hover"
              revealed={isPendingDelete}
              variant="accent"
              onClick={(e) => { e.stopPropagation(); onUpdate(); }}
              onMouseDown={(e) => e.preventDefault()}
              title={`Update "${name}" with the current column's settings`}
              aria-label={`Update template ${name}`}
              data-testid={`${testId}-update`}
            >
              <RotateCw size={11} strokeWidth={2} />
            </GhostIconButton>
          )}
          {hasRename && (
            <GhostIconButton
              reveal="on-row-hover"
              revealed={isPendingDelete}
              variant="accent"
              onClick={(e) => { e.stopPropagation(); onStartRename(); }}
              onMouseDown={(e) => e.preventDefault()}
              title={`Rename "${name}"`}
              aria-label={`Rename template ${name}`}
              data-testid={`${testId}-rename`}
            >
              <Pencil size={11} strokeWidth={2} />
            </GhostIconButton>
          )}
          {isPendingDelete ? (
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={(e) => { e.stopPropagation(); onConfirmDelete(); }}
              onMouseDown={(e) => e.preventDefault()}
              data-testid={`${testId}-delete-confirm`}
              title="Click to confirm delete"
              aria-label="Confirm delete template"
              className="inline-flex h-[22px] shrink-0 gap-1 rounded-[3px] border-[var(--ds-accent-negative)] bg-[color-mix(in_srgb,var(--ds-accent-negative)_18%,transparent)] px-2 text-[9px] font-bold uppercase tracking-[0.08em] text-[var(--ds-accent-negative)] shadow-none hover:bg-[color-mix(in_srgb,var(--ds-accent-negative)_24%,transparent)]"
            >
              <Trash2 size={10} strokeWidth={2.25} />
              <span>Delete</span>
            </Button>
          ) : (
            <GhostIconButton
              reveal="on-row-hover"
              variant="destructive"
              onClick={(e) => { e.stopPropagation(); onArmDelete(); }}
              onMouseDown={(e) => e.preventDefault()}
              title={`Delete "${name}"`}
              aria-label={`Delete template ${name}`}
              data-testid={`${testId}-delete`}
            >
              <Trash2 size={11} strokeWidth={2} />
            </GhostIconButton>
          )}
        </>
      )}

      {/* Cancel-rename — mousedown so it fires before the input's
          blur-commits handler. Always-visible (the input owns the
          row's left edge; this button needs to stay reachable). */}
      {isRenaming && (
        <GhostIconButton
          onMouseDown={(e) => {
            e.preventDefault();
            e.stopPropagation();
            onCancelRename();
          }}
          data-testid={`${testId}-rename-cancel`}
          title="Cancel rename"
          aria-label="Cancel rename"
        >
          <X size={11} strokeWidth={2} />
        </GhostIconButton>
      )}
    </Button>
  );
}

export function TemplateManager({
  templates,
  activeTemplateId,
  disabled,
  saveName,
  saveConfirmed,
  onSaveNameChange,
  onSave,
  onApply,
  onDelete,
  onUpdate,
  onRename,
  capturableFields,
  variant = 'panel',
  testIdPrefix = 'tpl',
}: TemplateManagerProps) {
  const isCompact = variant === 'compact';
  const isEmpty = templates.length === 0;

  // Inline rename state — at most one row in edit mode at a time.
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameDraft, setRenameDraft] = useState('');

  // Two-step delete state — armed-row id, auto-disarmed after 3s OR
  // when the template list changes.
  const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);
  const armTimerRef = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  const disarmDelete = () => {
    setPendingDeleteId(null);
    if (armTimerRef.current) clearTimeout(armTimerRef.current);
  };
  const armDelete = (id: string) => {
    setPendingDeleteId(id);
    if (armTimerRef.current) clearTimeout(armTimerRef.current);
    armTimerRef.current = setTimeout(() => setPendingDeleteId(null), 3000);
  };
  useEffect(() => () => { if (armTimerRef.current) clearTimeout(armTimerRef.current); }, []);

  // Disarm delete + cancel any in-flight rename whenever the template
  // list shape changes — otherwise stale state can target a row that
  // no longer exists.
  useEffect(() => {
    disarmDelete();
    if (renamingId && !templates.some((t) => t.id === renamingId)) {
      setRenamingId(null);
      setRenameDraft('');
    }
    /* eslint-disable-next-line react-hooks/exhaustive-deps */
  }, [templates.length]);

  const startRename = (id: string, currentName: string) => {
    disarmDelete();
    setRenamingId(id);
    setRenameDraft(currentName);
  };
  const commitRename = () => {
    const id = renamingId;
    if (!id) return;
    const trimmed = renameDraft.trim();
    const tpl = templates.find((t) => t.id === id);
    setRenamingId(null);
    setRenameDraft('');
    if (!trimmed || !tpl || tpl.name === trimmed) return;
    onRename?.(id, trimmed);
  };
  const cancelRename = () => {
    setRenamingId(null);
    setRenameDraft('');
  };

  const confirmDelete = (id: string) => {
    disarmDelete();
    onDelete(id);
  };

  return (
    <div
      data-testid={`${testIdPrefix}-manager`}
      className="flex flex-col gap-1.5"
      style={{
        minWidth: isCompact ? 320 : undefined,
        width: isCompact ? undefined : '100%',
      }}
    >
      {/* List of templates */}
      {!isEmpty && (
        <div
          data-testid={`${testIdPrefix}-list`}
          className="flex flex-col gap-px max-h-60 overflow-y-auto pr-0.5"
        >
          {templates.map((tpl) => (
            <TemplateRow
              key={tpl.id}
              id={tpl.id}
              name={tpl.name}
              isActive={tpl.id === activeTemplateId}
              isRenaming={renamingId === tpl.id}
              renameDraft={renameDraft}
              pendingDeleteId={pendingDeleteId}
              disabled={!!disabled}
              hasUpdate={!!onUpdate}
              hasRename={!!onRename}
              onApply={() => onApply(tpl.id)}
              onUpdate={() => onUpdate?.(tpl.id)}
              onStartRename={() => startRename(tpl.id, tpl.name)}
              onCommitRename={commitRename}
              onCancelRename={cancelRename}
              onRenameDraftChange={setRenameDraft}
              onArmDelete={() => armDelete(tpl.id)}
              onConfirmDelete={() => confirmDelete(tpl.id)}
              testId={`${testIdPrefix}-row-${tpl.id}`}
            />
          ))}
        </div>
      )}

      {/* Separator — only when both list and footer have content. */}
      {!isEmpty && (
        <div className="h-px bg-[color-mix(in_srgb,var(--ds-border-primary)_60%,transparent)] my-0.5" />
      )}

      {/* Save-as footer */}
      <div>
        <div className="text-[9px] font-semibold tracking-[0.6px] uppercase text-muted-foreground mb-1">
          Save current as new
        </div>
        <div className="flex gap-1.5">
          <Input
            type="text"
            value={saveName}
            onChange={(e) => onSaveNameChange(e.target.value)}
            placeholder={isEmpty ? 'Save your first template…' : 'Template name…'}
            disabled={disabled}
            data-testid={`${testIdPrefix}-save-input`}
            aria-label="New template name"
            onKeyDown={(e) => {
              if (e.key === 'Enter' && saveName.trim()) onSave();
            }}
            className="flex-1 min-w-0 h-7 px-2.5 rounded-[3px] text-[11px] shadow-none focus-visible:ring-0"
          />
          <Button
            type="button"
            variant="outline"
            size="icon"
            disabled={disabled || !saveName.trim()}
            onClick={onSave}
            onMouseDown={(e) => e.preventDefault()}
            data-testid={`${testIdPrefix}-save-btn`}
            title="Save current state as new template"
            aria-label="Save current state as new template"
            className={cn(
              'h-7 w-7 shrink-0 rounded-[2px] p-0 shadow-none transition-all transition-duration-[120ms]',
              saveConfirmed
                ? 'border-[color-mix(in_srgb,var(--ds-primary)_40%,transparent)] bg-[color-mix(in_srgb,var(--ds-primary)_14%,transparent)] text-[var(--ds-primary)]'
                : 'border-[var(--ds-border-primary)] bg-transparent text-[var(--ds-text-secondary)]',
            )}
          >
            {saveConfirmed ? <Check size={13} strokeWidth={2.5} /> : <Plus size={13} strokeWidth={2} />}
          </Button>
        </div>
      </div>

      {/* "What will be saved" hint — surfaces the captured-fields
          summary so the user knows what the snapshot includes BEFORE
          clicking save. Hidden when nothing is capturable (empty
          column) or the host didn't pass the prop. */}
      {capturableFields && capturableFields.length > 0 && (
        <div
          data-testid={`${testIdPrefix}-capture-hint`}
          className="text-[10px] text-muted-foreground leading-[1.4] pt-0.5"
        >
          Will save: <span className="text-[var(--ds-text-secondary)] font-medium">
            {capturableFields.join(' · ')}
          </span>
        </div>
      )}

      {/* Empty-state hint — shown when no templates exist yet. */}
      {isEmpty && (
        <div
          data-testid={`${testIdPrefix}-empty-hint`}
          className="text-[10px] text-muted-foreground leading-[1.4] pt-0.5"
        >
          Name a style, then click <span className="font-semibold text-[var(--ds-text-secondary)]">+</span> to save your first template.
        </div>
      )}
    </div>
  );
}
