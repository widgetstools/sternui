/**
 * @vitest-environment jsdom
 */
import { describe, expect, it, vi } from 'vitest';
import { activateSmartEdit } from './activate.js';

describe('activateSmartEdit', () => {
  it('handles cellKeyDown + and applies increment', async () => {
    const applyTransactionAsync = vi.fn().mockResolvedValue(undefined);
    let cellKeyDownHandler: ((e: { event?: Event }) => void) | null = null;

    const api = {
      getEditingCells: () => [],
      getCellRanges: () => [],
      getFocusedCell: () => ({ rowIndex: 0, column: { getColId: () => 'qty' } }),
      getDisplayedRowAtIndex: () => ({ id: 'r1', data: { id: 'r1', qty: 10 } }),
      getColumn: () => ({
        getColDef: () => ({ editable: true, field: 'qty', cellDataType: 'number' }),
      }),
      getCellValue: () => 10,
      applyTransactionAsync,
      addEventListener: (name: string, fn: typeof cellKeyDownHandler) => {
        if (name === 'cellKeyDown') cellKeyDownHandler = fn;
      },
      removeEventListener: vi.fn(),
    };

    const platform = {
      getState: () => ({
        settings: {
          enabled: true,
          incrementStep: 2,
          magnitudeShortcutsEnabled: true,
          enabledOps: ['add'],
          confirmThreshold: 0,
        },
      }),
      api: {
        onReady: (cb: (api: typeof api) => void) => {
          cb(api);
          return () => {};
        },
      },
    };

    const dispose = activateSmartEdit(platform as never);
    expect(cellKeyDownHandler).toBeTruthy();

    await cellKeyDownHandler!({
      event: { key: '+', preventDefault: vi.fn() } as unknown as KeyboardEvent,
    });

    expect(applyTransactionAsync).toHaveBeenCalled();
    dispose();
  });

  it('ignores when disabled', async () => {
    const applyTransactionAsync = vi.fn();
    let cellKeyDownHandler: ((e: { event?: Event }) => void) | null = null;

    const api = {
      getEditingCells: () => [],
      addEventListener: (name: string, fn: typeof cellKeyDownHandler) => {
        if (name === 'cellKeyDown') cellKeyDownHandler = fn;
      },
      removeEventListener: vi.fn(),
      applyTransactionAsync,
    };

    const platform = {
      getState: () => ({
        settings: {
          enabled: false,
          incrementStep: 1,
          magnitudeShortcutsEnabled: true,
          enabledOps: [],
          confirmThreshold: 0,
        },
      }),
      api: {
        onReady: (cb: (api: typeof api) => void) => {
          cb(api);
          return () => {};
        },
      },
    };

    activateSmartEdit(platform as never);
    await cellKeyDownHandler!({
      event: { key: '+', preventDefault: vi.fn() } as unknown as KeyboardEvent,
    });
    expect(applyTransactionAsync).not.toHaveBeenCalled();
  });
});
