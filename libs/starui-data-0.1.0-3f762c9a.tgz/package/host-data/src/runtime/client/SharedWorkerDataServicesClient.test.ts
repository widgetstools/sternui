/**
 * SharedWorkerDataServicesClient tests — wires a real MessageChannel between the
 * client and a Hub instance running in the same process. End-to-end
 * coverage of the round-trip: client.attach → Hub → emit → port →
 * client.handleMessage → listener.onDelta.
 *
 * The Mock provider is registered for these tests since it's the
 * only one that doesn't need an external transport.
 */

import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { createInPageWiring, SharedWorkerDataServicesClient } from './SharedWorkerDataServicesClient';
import { SharedWorkerDataServicesHub, type PortLike } from '../worker/SharedWorkerDataServicesHub';
import { registerProvider } from '../providers/registry';
import { isAppDataRequest, isRequest } from '../protocol';
import type { ProviderConfig } from '@starui/types';
import type { ProviderEmit, ProviderHandle } from '../providers/Provider';
import type { ProviderStats, ProviderStatus } from '../protocol';
import type { ConfigManager, AppConfigRow } from '@starui/host-config';
import { DataProviderConfigStore } from '../config/store.js';

interface TestController {
  emit: ProviderEmit;
  stops: number;
  restarts: Array<Record<string, unknown> | undefined>;
}

const controllers = new Map<string, TestController>();
let nextId = 1;

beforeEach(() => {
  controllers.clear();
  nextId = 1;
  registerProvider('mock' as ProviderConfig['providerType'], (cfg, emit) => {
    const ctrl: TestController = { emit, stops: 0, restarts: [] };
    const key = (cfg as unknown as { __key?: string }).__key ?? `c-${nextId++}`;
    controllers.set(key, ctrl);
    const handle: ProviderHandle = {
      stop() { ctrl.stops += 1; },
      restart(extra) { ctrl.restarts.push(extra); },
    };
    return handle;
  });
});

const cfg = (key = 'c-1'): ProviderConfig => ({
  providerType: 'mock',
  __key: key,
  keyColumn: 'id',
} as unknown as ProviderConfig);

interface Captured {
  deltas: Array<{ rows: readonly unknown[]; replace: boolean }>;
  statuses: Array<{ status: ProviderStatus; error?: string }>;
  stats: ProviderStats[];
}

function makeListener(): { listener: { onDelta: (rows: readonly unknown[], replace: boolean) => void; onStatus: (status: ProviderStatus, error?: string) => void }; captured: Captured } {
  const captured: Captured = { deltas: [], statuses: [], stats: [] };
  return {
    captured,
    listener: {
      onDelta: (rows, replace) => captured.deltas.push({ rows, replace }),
      onStatus: (status, error) => captured.statuses.push({ status, error }),
    },
  };
}

interface Wiring {
  hub: SharedWorkerDataServicesHub;
  client: SharedWorkerDataServicesClient;
  close(): void;
}

function attachPortToHub(hub: SharedWorkerDataServicesHub): (port: MessagePort) => void {
  return (port) => {
    const portLike: PortLike = { postMessage: (m) => port.postMessage(m) };
    port.addEventListener('message', (ev: MessageEvent) => {
      if (isRequest(ev.data)) hub.handleRequest(portLike, ev.data);
      else if (isAppDataRequest(ev.data)) hub.handleAppDataRequest(portLike, ev.data);
    });
    port.start();
  };
}

function wire(opts: { configManager?: ConfigManager } = {}): Wiring {
  const hub = new SharedWorkerDataServicesHub({
    ...(opts.configManager ? { configManager: opts.configManager } : {}),
  });
  const wiring = createInPageWiring(attachPortToHub(hub));
  return {
    hub,
    client: wiring.client,
    close: () => {
      wiring.close();
      void hub.dispose();
    },
  };
}

interface DualClientWiring {
  hub: SharedWorkerDataServicesHub;
  clientA: SharedWorkerDataServicesClient;
  clientB: SharedWorkerDataServicesClient;
  close(): void;
}

/** Two MessagePort clients wired to the same in-process hub (OpenFin multi-view shape). */
function wireTwoClients(opts: { configManager?: ConfigManager } = {}): DualClientWiring {
  const hub = new SharedWorkerDataServicesHub({
    ...(opts.configManager ? { configManager: opts.configManager } : {}),
  });
  const attach = attachPortToHub(hub);
  const wiringA = createInPageWiring(attach);
  const wiringB = createInPageWiring(attach);
  return {
    hub,
    clientA: wiringA.client,
    clientB: wiringB.client,
    close: () => {
      wiringA.close();
      wiringB.close();
      void hub.dispose();
    },
  };
}

function stubConfigManager(): ConfigManager & { _rows: Map<string, AppConfigRow> } {
  const rows = new Map<string, AppConfigRow>();
  return {
    _rows: rows,
    async getConfigsByUser(userId: string) {
      return [...rows.values()].filter((r) => r.userId === userId);
    },
    async getAllConfigs() { return [...rows.values()]; },
    async getAllConfigsUnfiltered() { return [...rows.values()]; },
    async getConfig(id: string) { return rows.get(id); },
    async saveConfig(row: AppConfigRow) { rows.set(row.configId, row); },
    async deleteConfig(id: string) { rows.delete(id); },
  } as unknown as ConfigManager & { _rows: Map<string, AppConfigRow> };
}

async function flush(): Promise<void> {
  for (let i = 0; i < 4; i++) {
    await new Promise<void>((r) => setTimeout(r, 0));
  }
}

describe('SharedWorkerDataServicesClient', () => {
  let w: Wiring;

  beforeEach(() => { w = wire(); });
  afterEach(() => w.close());

  it('attach() routes the first replace + status back to the listener', async () => {
    const { listener, captured } = makeListener();
    w.client.attach('p1', cfg(), listener);

    await flush();

    expect(captured.deltas).toHaveLength(1);
    expect(captured.deltas[0]).toMatchObject({ rows: [], replace: true });
    expect(captured.statuses[0]).toMatchObject({ status: 'loading' });
  });

  it('subsequent rows from the provider reach every attached listener', async () => {
    const a = makeListener();
    const b = makeListener();
    w.client.attach('p1', cfg(), a.listener);
    w.client.attach('p1', undefined, b.listener);
    await flush();

    a.captured.deltas.length = 0;
    b.captured.deltas.length = 0;
    controllers.get('c-1')!.emit({ rows: [{ id: 'r1', x: 1 }] });
    await flush();

    expect(a.captured.deltas).toHaveLength(1);
    expect(b.captured.deltas).toHaveLength(1);
    expect(a.captured.deltas[0].rows).toEqual([{ id: 'r1', x: 1 }]);
  });

  it('detach() stops further deliveries to that listener only', async () => {
    const a = makeListener();
    const b = makeListener();
    const subA = w.client.attach('p1', cfg(), a.listener);
    w.client.attach('p1', undefined, b.listener);
    await flush();

    w.client.detach(subA);
    await flush();
    a.captured.deltas.length = 0;
    b.captured.deltas.length = 0;
    controllers.get('c-1')!.emit({ rows: [{ id: 'r2' }] });
    await flush();

    expect(a.captured.deltas).toHaveLength(0);
    expect(b.captured.deltas).toHaveLength(1);
  });

  it('attach with extra triggers provider.restart on a running provider', async () => {
    const { listener } = makeListener();
    w.client.attach('p1', cfg(), listener);
    await flush();

    const { listener: l2 } = makeListener();
    w.client.attach('p1', undefined, l2, { extra: { asOfDate: '2026-04-01' } });
    await flush();

    expect(controllers.get('c-1')!.restarts).toEqual([{ asOfDate: '2026-04-01' }]);
  });

  it('subscribe with extra waits for fresh snapshot instead of stale cache replay', async () => {
    const primer = w.client.subscribe('p1', cfg());
    await flush();
    controllers.get('c-1')!.emit({ rows: [{ id: 'stale', x: 1 }], replace: true });
    controllers.get('c-1')!.emit({ status: 'ready' });
    await primer.snapshot;
    primer.unsubscribe();

    const commits: Array<readonly { id: string; x: number }[]> = [];
    const handle = w.client.subscribe<{ id: string; x: number }>(
      'p1',
      undefined,
      { extra: { __refresh: 1 } },
    );
    handle.onSnapshotCommit((rows) => commits.push(rows));
    await flush();

    expect(commits).toHaveLength(0);

    controllers.get('c-1')!.emit({ status: 'loading' });
    controllers.get('c-1')!.emit({ rows: [{ id: 'fresh', x: 2 }], replace: true });
    controllers.get('c-1')!.emit({ status: 'ready' });

    const snapshot = await handle.snapshot;
    expect(snapshot).toEqual([{ id: 'fresh', x: 2 }]);
    expect(commits).toEqual([[{ id: 'fresh', x: 2 }]]);
    handle.unsubscribe();
  });

  it('onSnapshotCommit fires again when the provider re-snapshots on an existing subId', async () => {
    const handle = w.client.subscribe<{ id: string; x: number }>('p1', cfg());
    const commits: Array<readonly { id: string; x: number }[]> = [];
    handle.onSnapshotCommit((rows) => commits.push(rows));
    await flush();

    controllers.get('c-1')!.emit({ rows: [{ id: 'r1', x: 1 }], replace: true });
    controllers.get('c-1')!.emit({ status: 'ready' });
    await handle.snapshot;
    expect(commits).toEqual([[{ id: 'r1', x: 1 }]]);

    controllers.get('c-1')!.emit({ status: 'loading' });
    controllers.get('c-1')!.emit({ rows: [{ id: 'r1', x: 99 }], replace: true });
    controllers.get('c-1')!.emit({ status: 'ready' });
    await flush();

    expect(commits).toEqual([
      [{ id: 'r1', x: 1 }],
      [{ id: 'r1', x: 99 }],
    ]);
    handle.unsubscribe();
  });

  it('subscribe() resolves the snapshot promise when the provider becomes ready, then routes updates to onUpdate', async () => {
    const handle = w.client.subscribe<{ id: string; x: number }>('p1', cfg());
    const updates: Array<readonly { id: string; x: number }[]> = [];
    handle.onUpdate((rows) => { updates.push(rows); });
    await flush();

    // Provider's snapshot phase: rows arrive as replace=true, then
    // status flips to ready.
    controllers.get('c-1')!.emit({
      rows: [{ id: 'r1', x: 1 }, { id: 'r2', x: 2 }],
      replace: true,
    });
    controllers.get('c-1')!.emit({ status: 'ready' });

    const snapshot = await handle.snapshot;
    expect(snapshot).toHaveLength(2);
    expect(snapshot[0]).toEqual({ id: 'r1', x: 1 });

    // Subsequent live tick lands in onUpdate, NOT in the snapshot.
    controllers.get('c-1')!.emit({ rows: [{ id: 'r2', x: 99 }] });
    await flush();

    expect(updates).toHaveLength(1);
    expect(updates[0]).toEqual([{ id: 'r2', x: 99 }]);

    handle.unsubscribe();
  });

  it('subscribe() buffers updates that arrive before onUpdate is registered, flushes on registration', async () => {
    const handle = w.client.subscribe<{ id: string; x: number }>('p1', cfg());
    await flush();

    // Snapshot delivery: rows + ready status.
    controllers.get('c-1')!.emit({ rows: [{ id: 'r1', x: 1 }], replace: true });
    controllers.get('c-1')!.emit({ status: 'ready' });
    await handle.snapshot;

    // Now a couple of live updates BEFORE onUpdate is registered.
    controllers.get('c-1')!.emit({ rows: [{ id: 'r1', x: 2 }] });
    controllers.get('c-1')!.emit({ rows: [{ id: 'r1', x: 3 }] });
    await flush();

    // Register the handler — buffered updates flush in order.
    const seen: Array<readonly { id: string; x: number }[]> = [];
    handle.onUpdate((rows) => { seen.push(rows); });

    expect(seen).toHaveLength(2);
    expect(seen[0]).toEqual([{ id: 'r1', x: 2 }]);
    expect(seen[1]).toEqual([{ id: 'r1', x: 3 }]);

    handle.unsubscribe();
  });

  it('subscribe() resolves chunked late-join replay into a full assembled snapshot', async () => {
    const rows = Array.from({ length: 1200 }, (_, i) => ({ id: `r${i}` }));
    const primer = w.client.subscribe('p1', cfg());
    await flush();
    controllers.get('c-1')!.emit({ rows, replace: true });
    controllers.get('c-1')!.emit({ status: 'ready' });
    await primer.snapshot;
    primer.unsubscribe();

    const counts: number[] = [];
    const late = w.client.subscribe<{ id: string }>('p1');
    late.onRowsReceived((n) => counts.push(n));
    const snapshot = await late.snapshot;
    expect(snapshot).toHaveLength(1200);
    expect(snapshot[0]).toEqual({ id: 'r0' });
    expect(snapshot[1199]).toEqual({ id: 'r1199' });
    expect(counts.length).toBeGreaterThan(0);
    expect(counts[counts.length - 1]).toBe(1200);
    late.unsubscribe();
  });

  it('subscribe() to an already-ready provider resolves immediately with the cached snapshot', async () => {
    // Provider 1: a primer subscriber that drives the cache to ready.
    const primer = w.client.subscribe('p1', cfg());
    await flush();
    controllers.get('c-1')!.emit({ rows: [{ id: 'r1', x: 1 }, { id: 'r2', x: 2 }], replace: true });
    controllers.get('c-1')!.emit({ status: 'ready' });
    await primer.snapshot;
    primer.unsubscribe();

    // Provider 2: a fresh subscriber attaching AFTER ready. The Hub
    // should replay the cache + ready status; the subscribe handle's
    // snapshot promise should resolve without any further provider
    // events.
    const late = w.client.subscribe<{ id: string; x: number }>('p1');
    const snapshot = await late.snapshot;
    expect(snapshot).toHaveLength(2);
    late.unsubscribe();
  });

  it('subscribe().refresh() replays hub cache without provider.restart', async () => {
    const handle = w.client.subscribe<{ id: string; x: number }>('p1', cfg());
    await flush();
    controllers.get('c-1')!.emit({ rows: [{ id: 'r1', x: 1 }, { id: 'r2', x: 2 }], replace: true });
    controllers.get('c-1')!.emit({ status: 'ready' });
    await handle.snapshot;

    controllers.get('c-1')!.restarts.length = 0;
    const replayed = await handle.refresh();
    expect(replayed).toHaveLength(2);
    expect(replayed[0]).toEqual({ id: 'r1', x: 1 });
    expect(controllers.get('c-1')!.restarts).toHaveLength(0);

    handle.unsubscribe();
  });

  it('subscribe() surfaces upstream rows-received before chunked hub deltas land', async () => {
    const handle = w.client.subscribe('p1', cfg());
    await flush();
    const counts: number[] = [];
    handle.onRowsReceived((n) => counts.push(n));

    controllers.get('c-1')!.emit({ rowsReceived: 50 });
    controllers.get('c-1')!.emit({ rowsReceived: 120 });
    await flush();
    expect(counts).toEqual([0, 50, 120]);

    controllers.get('c-1')!.emit({
      rows: Array.from({ length: 120 }, (_, i) => ({ id: `r${i}` })),
      replace: true,
    });
    controllers.get('c-1')!.emit({ status: 'ready' });
    await handle.snapshot;
    expect(counts[counts.length - 1]).toBe(120);

    handle.unsubscribe();
  });

  it('subscribe() rejects the snapshot promise when the provider emits an error before snapshot lands', async () => {
    const handle = w.client.subscribe('p1', cfg());
    await flush();

    controllers.get('c-1')!.emit({ status: 'error', error: 'upstream blew up' });

    await expect(handle.snapshot).rejects.toThrow(/upstream blew up/);
    handle.unsubscribe();
  });

  it('subscribe().unsubscribe() rejects a pending snapshot promise so awaiters do not hang', async () => {
    const handle = w.client.subscribe('p1', cfg());
    await flush();
    // Don't emit anything; just unsubscribe.
    handle.unsubscribe();
    await expect(handle.snapshot).rejects.toThrow(/cancelled/);
  });

  it('stop() tears the provider down and surfaces error to subscribers', async () => {
    const { listener, captured } = makeListener();
    w.client.attach('p1', cfg(), listener);
    await flush();

    w.client.stop('p1');
    await flush();

    expect(controllers.get('c-1')!.stops).toBe(1);
    const err = captured.statuses.find((s) => s.status === 'error');
    expect(err).toBeTruthy();
  });

  it('attachStats() delivers stats events at the sampler cadence', async () => {
    const captured: ProviderStats[] = [];
    w.client.attach('p1', cfg(), makeListener().listener);
    w.client.attachStats('p1', { onStats: (s) => captured.push(s) });
    await flush();

    expect(captured.length).toBeGreaterThan(0);
    expect(captured[0]).toMatchObject({ rowCount: 0, subscriberCount: 1 });
  });

  it('close() detaches all listeners and ignores subsequent calls', () => {
    const { listener } = makeListener();
    w.client.attach('p1', cfg(), listener);
    w.client.close();
    expect(() => w.client.attach('p2', cfg('c-2'), listener)).toThrow();
    // Idempotent.
    w.client.close();
  });
});

describe('SharedWorkerDataServicesClient — attachAppData', () => {
  let w: Wiring;
  let cm: ReturnType<typeof stubConfigManager>;
  beforeEach(() => {
    cm = stubConfigManager();
    w = wire({ configManager: cm });
  });
  afterEach(() => w.close());

  it('hub-hydrated state surfaces through mirror sync get on attach', async () => {
    cm._rows.set('ad-1', {
      configId: 'ad-1', appId: 'TestApp', userId: 'alice',
      componentType: 'appdata', componentSubType: 'appdata',
      isTemplate: false, displayText: 'positions',
      payload: { values: { asOfDate: '2026-04-01' } },
      createdBy: 'alice', updatedBy: 'alice',
      creationTime: '0', updatedTime: '0',
    } as AppConfigRow);
    await w.hub.hydrateAppData('alice');

    const mirror = w.client.attachAppData({ userId: 'alice' });
    await mirror.attach();
    await mirror.ready();

    expect(mirror.get('positions', 'asOfDate')).toBe('2026-04-01');
  });

  it('two mirrors converge on a write', async () => {
    await w.hub.hydrateAppData('alice');
    const a = w.client.attachAppData({ userId: 'alice', subId: 'a' });
    const b = w.client.attachAppData({ userId: 'alice', subId: 'b' });
    await a.attach();
    await b.attach();
    await Promise.all([a.ready(), b.ready()]);

    await a.set('positions', 'asOfDate', '2026-05-08');
    expect(b.get('positions', 'asOfDate')).toBe('2026-05-08');
  });

  it('detachAppData stops further deltas reaching the mirror', async () => {
    await w.hub.hydrateAppData('alice');
    const a = w.client.attachAppData({ userId: 'alice', subId: 'a' });
    const b = w.client.attachAppData({ userId: 'alice', subId: 'b' });
    await a.attach();
    await b.attach();
    await Promise.all([a.ready(), b.ready()]);

    w.client.detachAppData(a);
    await b.set('positions', 'asOfDate', '2026-05-08');

    // a stayed pre-detach; its sync state is whatever the snapshot held.
    expect(a.get('positions', 'asOfDate')).toBeUndefined();
    expect(b.get('positions', 'asOfDate')).toBe('2026-05-08');
  });

  it('close() clears AppData mirror routing', async () => {
    await w.hub.hydrateAppData('alice');
    const a = w.client.attachAppData({ userId: 'alice', subId: 'a' });
    await a.attach();
    await a.ready();
    w.client.close();

    // After close, set() resolves but the underlying postMessage is a
    // no-op (port closed). The mirror's pending ack stays unresolved
    // unless the client surfaces an error. Verify no throw.
    // The ack-resolution path is exercised in the AppDataMirror tests
    // (in-process, no port).
    expect(() => w.client.detachAppData(a)).not.toThrow();
  });
});

function mockProviderRow(id: string, testKey = 'c-1'): AppConfigRow {
  return {
    configId: id,
    appId: 'TestApp',
    userId: 'system',
    componentType: 'data-provider',
    componentSubType: 'mock',
    isTemplate: false,
    displayText: id,
    payload: {
      providerType: 'mock',
      keyColumn: 'id',
      __key: testKey,
      __providerMeta: { public: true },
    },
    createdBy: 'dev1',
    updatedBy: 'dev1',
    creationTime: '2026-01-01T00:00:00.000Z',
    updatedTime: '2026-01-01T00:00:00.000Z',
  };
}

describe('SharedWorkerDataServicesClient — config catalog RPC', () => {
  it('waitForCatalogReady resolves when the hub catalog is hydrated', async () => {
    const cm = stubConfigManager();
    cm._rows.set('p1', mockProviderRow('p1'));
    const w = wire({ configManager: cm });
    await w.hub.hydrateCatalog();
    await w.client.waitForCatalogReady();
    w.close();
  });

  it('getProviderConfig and listProviderConfigs round-trip through the hub', async () => {
    const cm = stubConfigManager();
    cm._rows.set('p1', mockProviderRow('p1'));
    cm._rows.set('p2', mockProviderRow('p2', 'c-2'));
    const w = wire({ configManager: cm });
    await w.hub.hydrateCatalog();

    const one = await w.client.getProviderConfig('p1');
    expect(one?.providerId).toBe('p1');

    const all = await w.client.listProviderConfigs();
    expect(all.map((p) => p.providerId).sort()).toEqual(['p1', 'p2']);

    w.close();
  });

  it('cfg-free subscribe starts a provider from the worker catalog', async () => {
    const cm = stubConfigManager();
    cm._rows.set('p1', mockProviderRow('p1'));
    const w = wire({ configManager: cm });
    await w.hub.hydrateCatalog();

    const handle = w.client.subscribe<{ id: string }>('p1');
    await flush();

    expect(handle).toBeTruthy();
    controllers.get('c-1')!.emit({ rows: [{ id: 'r1' }], replace: true });
    controllers.get('c-1')!.emit({ status: 'ready' });
    const snapshot = await handle.snapshot;
    expect(snapshot).toEqual([{ id: 'r1' }]);
    handle.unsubscribe();
    w.close();
  });

  it('second hub client cfg-free attach receives snapshot cached by the first client', async () => {
    const cm = stubConfigManager();
    cm._rows.set('p1', mockProviderRow('p1'));
    const dual = wireTwoClients({ configManager: cm });
    await dual.hub.hydrateCatalog();
    await dual.clientA.waitForCatalogReady();
    await dual.clientB.waitForCatalogReady();

    const primer = dual.clientA.subscribe('p1', cfg());
    await flush();
    controllers.get('c-1')!.emit({
      rows: [{ id: 'r1' }, { id: 'r2' }],
      replace: true,
    });
    controllers.get('c-1')!.emit({ status: 'ready' });
    await primer.snapshot;

    const late = dual.clientB.subscribe<{ id: string }>('p1');
    const snapshot = await late.snapshot;
    expect(snapshot).toEqual([{ id: 'r1' }, { id: 'r2' }]);
    expect(controllers.get('c-1')!.restarts).toHaveLength(0);

    primer.unsubscribe();
    late.unsubscribe();
    dual.close();
  });

  it('configStore.save() invalidates the worker catalog so getProviderConfig sees updates', async () => {
    const cm = stubConfigManager();
    cm._rows.set('p1', mockProviderRow('p1'));
    const w = wire({ configManager: cm });
    await w.hub.hydrateCatalog();

    const store = new DataProviderConfigStore(
      cm,
      (providerId) => w.client.invalidateConfig(providerId),
    );

    await store.save({
      providerId: 'p1',
      name: 'Renamed',
      providerType: 'mock',
      config: { providerType: 'mock', keyColumn: 'id', __key: 'c-1' } as never,
      userId: 'system',
      public: true,
    }, 'dev1');
    await flush();

    const cfg = await w.client.getProviderConfig('p1');
    expect(cfg?.name).toBe('Renamed');
    w.close();
  });
});
