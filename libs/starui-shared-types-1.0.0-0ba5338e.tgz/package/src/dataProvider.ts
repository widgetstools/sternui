// DataProvider configuration types for Star Trading Platform
// These configs are stored as UnifiedConfig with componentType='datasource'

/**
 * Provider type enumeration
 */
export const PROVIDER_TYPES = {
  STOMP: 'stomp',
  REST: 'rest',
  WEBSOCKET: 'websocket',
  SOCKETIO: 'socketio',
  MOCK: 'mock',
  APPDATA: 'appdata'
} as const;

export type ProviderType = typeof PROVIDER_TYPES[keyof typeof PROVIDER_TYPES];

/**
 * Provider type to ComponentSubType mapping
 */
export const PROVIDER_TYPE_TO_COMPONENT_SUBTYPE: Record<ProviderType, string> = {
  [PROVIDER_TYPES.STOMP]: 'stomp',
  [PROVIDER_TYPES.REST]: 'rest',
  [PROVIDER_TYPES.WEBSOCKET]: 'websocket',
  [PROVIDER_TYPES.SOCKETIO]: 'socketio',
  [PROVIDER_TYPES.MOCK]: 'mock',
  [PROVIDER_TYPES.APPDATA]: 'appdata'
};

/**
 * ComponentSubType to Provider type mapping
 */
export const COMPONENT_SUBTYPE_TO_PROVIDER_TYPE: Record<string, ProviderType> = {
  'stomp': PROVIDER_TYPES.STOMP,
  'rest': PROVIDER_TYPES.REST,
  'websocket': PROVIDER_TYPES.WEBSOCKET,
  'socketio': PROVIDER_TYPES.SOCKETIO,
  'mock': PROVIDER_TYPES.MOCK,
  'appdata': PROVIDER_TYPES.APPDATA,
  // Capitalized (backward compatibility)
  'Stomp': PROVIDER_TYPES.STOMP,
  'Rest': PROVIDER_TYPES.REST,
  'WebSocket': PROVIDER_TYPES.WEBSOCKET,
  'SocketIO': PROVIDER_TYPES.SOCKETIO,
  'Mock': PROVIDER_TYPES.MOCK,
  'AppData': PROVIDER_TYPES.APPDATA
};

/**
 * Connection state enumeration
 */
export const CONNECTION_STATES = {
  DISCONNECTED: 'disconnected',
  CONNECTING: 'connecting',
  CONNECTED: 'connected',
  RECONNECTING: 'reconnecting',
  ERROR: 'error'
} as const;

export type ConnectionState = typeof CONNECTION_STATES[keyof typeof CONNECTION_STATES];

/**
 * Field information from schema inference
 */
export interface FieldInfo {
  path: string;
  type: 'string' | 'number' | 'boolean' | 'date' | 'object' | 'array';
  nullable: boolean;
  sample?: any;
  children?: Record<string, FieldInfo>;
}

/**
 * Column definition for AG-Grid
 */
export interface ColumnDefinition {
  field: string;
  headerName: string;
  cellDataType?: 'text' | 'number' | 'boolean' | 'date' | 'dateString' | 'object';
  width?: number;
  filter?: string | boolean;
  sortable?: boolean;
  resizable?: boolean;
  hide?: boolean;
  type?: string;
  valueFormatter?: string;
  cellRenderer?: string;
}

/**
 * STOMP Provider Configuration
 */
export interface StompProviderConfig {
  providerType: 'stomp';
  websocketUrl: string;
  listenerTopic: string;
  requestMessage?: string;
  requestBody?: string;
  snapshotEndToken?: string;
  /**
   * Unique-row identity. A SINGLE column name keys rows by that one
   * field; an array of column names keys rows by the joined values
   * (separator: `-`) — used for datasets with composite primary keys.
   * Drives both the worker-side cache (Hub) and AG-Grid's `getRowId`.
   */
  keyColumn?: string | readonly string[];
  snapshotTimeoutMs?: number;
  manualTopics?: boolean;
  dataType?: 'positions' | 'trades' | 'orders' | 'custom';
  messageRate?: number;
  batchSize?: number;
  autoStart?: boolean;
  heartbeat?: {
    outgoing?: number;
    incoming?: number;
  };
  inferredFields?: FieldInfo[];
  columnDefinitions?: ColumnDefinition[];
  /**
   * Conflate row updates by this column before fanning out to
   * subscribers. Two updates for the same key value within a
   * `throttleMs` window collapse into the latest one (upsert
   * semantics). Typically set to the same value as `keyColumn` so
   * grids see exactly one update per row per flush. Omit for
   * "every row update is delivered" behaviour.
   */
  conflateByKey?: string;
  /**
   * Coalesce row-update fanout into trailing-edge bursts every
   * `throttleMs`. 0 / undefined → immediate fanout (no batching).
   * The conflation window above only takes effect when this is set.
   */
  throttleMs?: number;
  /**
   * Reconnect policy. Today only `initialDelayMs` is honoured (it
   * becomes the stompjs `reconnectDelay`); full exponential backoff +
   * jitter + maxAttempts requires bypassing stompjs's auto-reconnect
   * and is tracked as a follow-up. The fields are reserved here so
   * configurators can author them now without a schema migration.
   */
  reconnect?: {
    /** Static reconnect delay in ms. Default 5000 (matches prior behaviour). */
    initialDelayMs?: number;
    /** Reserved for exp-backoff implementation. Currently ignored. */
    maxDelayMs?: number;
    /** Reserved for exp-backoff implementation. Currently ignored. */
    jitter?: 'full' | 'equal' | 'none';
    /** Reserved for exp-backoff implementation. Currently ignored. */
    maxAttempts?: number;
  };
}

/**
 * REST Provider Configuration
 */
export interface RestProviderConfig {
  providerType: 'rest';
  baseUrl: string;
  endpoint: string;
  method: 'GET' | 'POST';
  queryParams?: Record<string, string>;
  body?: string;
  headers?: Record<string, string>;
  pollInterval?: number;
  paginationMode?: 'offset' | 'cursor' | 'page';
  pageSize?: number;
  auth?: {
    type: 'bearer' | 'apikey' | 'basic';
    credentials: string;
    headerName?: string;
  };
  timeout?: number;
  /**
   * Required for streaming consumers (MarketsGrid). The column whose
   * value uniquely identifies a row — drives RowCache upsert + AG-Grid
   * `getRowId`. Accepts an array of column names for composite keys
   * (joined with `-`).
   */
  keyColumn?: string | readonly string[];
  /**
   * Path inside the JSON response that holds the rows array.
   * Dot notation; e.g. `data.results`. Default: response is the
   * rows array directly.
   */
  rowsPath?: string;
  /** Persisted schema introspection — see StompProviderConfig. */
  inferredFields?: FieldInfo[];
  columnDefinitions?: ColumnDefinition[];
  /** See StompProviderConfig — same fanout knobs apply. */
  conflateByKey?: string;
  throttleMs?: number;
}

/**
 * WebSocket Provider Configuration
 */
export interface WebSocketProviderConfig {
  providerType: 'websocket';
  url: string;
  protocol?: string;
  messageFormat: 'json' | 'binary' | 'text';
  heartbeatInterval?: number;
  reconnectAttempts?: number;
  reconnectDelay?: number;
  /** Message to send after connection to begin data subscription. */
  subscribeMessage?: string;
}

/**
 * Socket.IO Provider Configuration
 */
export interface SocketIOProviderConfig {
  providerType: 'socketio';
  url: string;
  namespace?: string;
  events: {
    snapshot: string;
    update: string;
    delete?: string;
  };
  rooms?: string[];
  auth?: any;
  reconnection?: boolean;
  reconnectionDelay?: number;
  /** Simplified single-event name alternative to the `events` object. */
  eventName?: string;
}

/**
 * Mock Provider Configuration
 */
export interface MockProviderConfig {
  providerType: 'mock';
  dataType: 'positions' | 'trades' | 'orders' | 'custom';
  updateInterval?: number;
  /** Alias for `updateInterval` in ms — preserved for UI template compatibility. */
  updateIntervalMs?: number;
  rowCount?: number;
  enableUpdates?: boolean;
  customData?: any[];
  /**
   * Unique-row identity, same semantics as the other streaming
   * configs. Required when this cfg is attached through the
   * SharedWorker hub (`useProviderStream` / `client.attach`) — the
   * hub keys its row cache by `keyColumn` and silently drops rows
   * that don't resolve a value, so a missing field surfaces as an
   * empty grid. Safe to omit when calling `startMock` directly
   * in-process (the in-process path doesn't go through the cache).
   *
   * Typical values per dataType: `'cusip'` for positions,
   * `'tradeId'` for trades, `'id'` for orders.
   */
  keyColumn?: string | readonly string[];
}

/**
 * AppData Variable
 */
export interface AppDataVariable {
  key: string;
  value: string | number | boolean | object;
  type: 'string' | 'number' | 'boolean' | 'json';
  description?: string;
  sensitive?: boolean;
  /**
   * Durability of this key:
   *   'volatile'  — in-memory only, lost on worker restart (default).
   *                 Auth tokens, transient selections, rate-limited
   *                 caches, anything sensitive that shouldn't leak
   *                 across sessions.
   *   'persisted' — written through to ConfigService on every `put`
   *                 and rehydrated from ConfigService when the
   *                 AppData provider configures. User preferences,
   *                 long-lived feature flags, anything the user
   *                 expects to survive a reboot.
   *
   * Defaults to 'volatile' for back-compat. Existing configs without
   * this field behave as today.
   */
  durability?: 'volatile' | 'persisted';
}

/**
 * AppData Provider Configuration
 */
export interface AppDataProviderConfig {
  providerType: 'appdata';
  variables: Record<string, AppDataVariable>;
}

/**
 * Union type for all provider configurations
 */
export type ProviderConfig =
  | StompProviderConfig
  | RestProviderConfig
  | WebSocketProviderConfig
  | SocketIOProviderConfig
  | MockProviderConfig
  | AppDataProviderConfig;

/**
 * Provider capabilities
 */
export interface ProviderCapabilities {
  hasSnapshot: boolean;
  hasRealtime: boolean;
  hasPagination: boolean;
  hasFiltering: boolean;
  hasSorting: boolean;
  hasSearch: boolean;
  maxRowsPerRequest?: number;
}

/**
 * Provider statistics for monitoring
 */
export interface ProviderStatistics {
  snapshotRowsReceived: number;
  updateRowsReceived: number;
  bytesReceived: number;
  snapshotBytesReceived: number;
  updateBytesReceived: number;
  connectionCount: number;
  disconnectionCount: number;
  isConnected: boolean;
  mode: 'idle' | 'snapshot' | 'realtime';
  lastMessageTime: number | null;
  connectionDuration?: number;
  errorCount?: number;
}

/**
 * Template variables for STOMP topic resolution
 */
export interface TemplateVariables {
  clientId: string;
  userId?: string;
  timestamp?: number;
  [key: string]: string | number | undefined;
}

/**
 * DataProvider configuration wrapper
 */
export interface DataProviderConfig {
  providerId?: string;
  name: string;
  description?: string;
  providerType: ProviderType;
  config: ProviderConfig;
  tags?: string[];
  isDefault?: boolean;
  userId: string;
  /**
   * Visibility:
   *   true  → row is saved with userId='system' (visible to everyone
   *           sharing the appId).
   *   false / undefined → row is saved with the active userId
   *           (visible only to the author).
   *
   * The configurator surfaces this as a single "Public" toggle.
   */
  public?: boolean;
}

/**
 * Validation result for provider configurations
 */
export interface ProviderValidationResult {
  isValid: boolean;
  errors: string[];
  warnings?: string[];
}

/**
 * Provider connection test result
 */
export interface ProviderTestResult {
  success: boolean;
  connectionState: ConnectionState;
  responseTime?: number;
  error?: string;
  metadata?: {
    serverVersion?: string;
    capabilities?: ProviderCapabilities;
    sampleData?: any[];
  };
}

/**
 * Default provider configurations for quick setup
 */
export const DEFAULT_PROVIDER_CONFIGS: Record<ProviderType, Partial<ProviderConfig>> = {
  stomp: {
    providerType: 'stomp',
    listenerTopic: '',
    websocketUrl: '',
    snapshotEndToken: 'Success',
    requestBody: 'START',
    snapshotTimeoutMs: 60000,
    manualTopics: false,
    dataType: 'positions',
    messageRate: 1000,
    autoStart: false,
    heartbeat: {
      outgoing: 4000,
      incoming: 4000
    },
    inferredFields: [],
    columnDefinitions: []
  },
  rest: {
    providerType: 'rest',
    baseUrl: '',
    endpoint: '',
    method: 'GET',
    pollInterval: 5000,
    pageSize: 100,
    timeout: 30000
  },
  websocket: {
    providerType: 'websocket',
    url: '',
    messageFormat: 'json',
    heartbeatInterval: 30000,
    reconnectAttempts: 5,
    reconnectDelay: 5000
  },
  socketio: {
    providerType: 'socketio',
    url: '',
    namespace: '/',
    reconnection: true,
    reconnectionDelay: 5000
  },
  mock: {
    providerType: 'mock',
    dataType: 'positions',
    updateInterval: 2000,
    rowCount: 20,
    enableUpdates: true
  },
  appdata: {
    providerType: 'appdata',
    variables: {}
  }
};

/**
 * Helper function to get default config for a provider type
 */
export function getDefaultProviderConfig(type: ProviderType): Partial<ProviderConfig> {
  return { ...DEFAULT_PROVIDER_CONFIGS[type] };
}

/**
 * Validate provider configuration
 */
export function validateProviderConfig(config: ProviderConfig): ProviderValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  if (!config.providerType) {
    errors.push('Provider type is required');
  }

  switch (config.providerType) {
    case 'stomp': {
      const stompConfig = config as StompProviderConfig;
      if (stompConfig.websocketUrl && !stompConfig.websocketUrl.startsWith('ws://') && !stompConfig.websocketUrl.startsWith('wss://')) {
        warnings.push('WebSocket URL should typically start with ws:// or wss://');
      }
      if (stompConfig.snapshotTimeoutMs && stompConfig.snapshotTimeoutMs < 1000) {
        warnings.push('Snapshot timeout is very low (< 1 second)');
      }
      break;
    }
    case 'rest': {
      const restConfig = config as RestProviderConfig;
      if (restConfig.baseUrl && !restConfig.baseUrl.startsWith('http://') && !restConfig.baseUrl.startsWith('https://')) {
        warnings.push('Base URL should typically start with http:// or https://');
      }
      if (restConfig.pollInterval && restConfig.pollInterval < 1000) {
        warnings.push('Poll interval is very low (< 1 second), may cause high server load');
      }
      break;
    }
    case 'websocket': {
      const wsConfig = config as WebSocketProviderConfig;
      if (wsConfig.url && !wsConfig.url.startsWith('ws://') && !wsConfig.url.startsWith('wss://')) {
        warnings.push('URL should typically start with ws:// or wss://');
      }
      break;
    }
  }

  return {
    isValid: errors.length === 0,
    errors,
    warnings: warnings.length > 0 ? warnings : undefined
  };
}

// ─── Row-id derivation ────────────────────────────────────────────────

/** Separator used when composing row ids from multiple key columns. */
export const COMPOSITE_KEY_SEPARATOR = '-';

/**
 * Normalize a `keyColumn` config value (single string OR array) into a
 * readonly array of column names. Empty / whitespace-only entries are
 * dropped. Returns `null` when no usable column is configured.
 */
export function normalizeKeyColumns(
  keyColumn: string | readonly string[] | null | undefined,
): readonly string[] | null {
  if (keyColumn == null) return null;
  const arr = Array.isArray(keyColumn) ? keyColumn : [keyColumn];
  const cleaned = arr
    .filter((c): c is string => typeof c === 'string')
    .map((c) => c.trim())
    .filter((c) => c.length > 0);
  return cleaned.length > 0 ? cleaned : null;
}

/**
 * Resolve a value at a dot-separated path on a row.
 *
 * Behaviour:
 *   1. If the row carries a literal flat key matching the FULL path
 *      (e.g. `row['weird.key']`), that wins. This handles the rare
 *      case where source data legitimately encodes dots in keys.
 *   2. Otherwise, split on `.` and walk nested objects:
 *      `getValueByPath({a:{b:{c:1}}}, 'a.b.c') === 1`.
 *   3. Returns `undefined` for any missing segment along the way.
 *
 * Mirrors what AG-Grid's auto-dot-walk does, with the literal-key
 * priority added so consumers don't accidentally lose data on weird
 * upstream feeds.
 */
export function getValueByPath(row: unknown, path: string): unknown {
  if (row == null || typeof row !== 'object') return undefined;
  const obj = row as Record<string, unknown>;
  // Step 1 — literal flat key wins (handles `{"weird.key": …}`).
  if (Object.prototype.hasOwnProperty.call(obj, path)) return obj[path];
  // Step 2 — dot-walk nested objects.
  if (!path.includes('.')) return undefined;
  let cursor: unknown = obj;
  for (const seg of path.split('.')) {
    if (cursor == null || typeof cursor !== 'object') return undefined;
    cursor = (cursor as Record<string, unknown>)[seg];
  }
  return cursor;
}

/**
 * Compose a unique row id from one or more configured key columns.
 *
 * - **Single column**: returns the row's value at that column, stringified.
 * - **Composite (≥ 2 columns)**: joins each column's stringified value
 *   with `-`, e.g. `col1=A, col2=B, col3=42` → `"A-B-42"`.
 * - **Nested key columns**: dot-separated paths (e.g. `position.id`) are
 *   resolved via `getValueByPath`, which dot-walks nested objects with
 *   a literal-flat-key fallback. Required because feeds frequently
 *   surface row identity inside a nested envelope (e.g.
 *   `{ meta: { id: 'POS-42' }, … }`) and the FieldsTab tree exposes
 *   those paths as candidate key columns directly.
 * - **Missing values**: if ANY configured column resolves to null/undefined,
 *   returns `null` — the caller treats the row as un-keyable.
 *   Surfacing a row whose composite key is partially-defined would silently
 *   conflate distinct rows under a sentinel like `"A--42"`.
 *
 * Used by both the worker-side Hub cache and AG-Grid's `getRowId` so the
 * cache key and the grid row id stay byte-identical (required for live
 * updates to find the right rendered row).
 */
export function composeRowId(
  row: unknown,
  keyColumn: string | readonly string[] | null | undefined,
): string | null {
  const cols = normalizeKeyColumns(keyColumn);
  if (!cols || !row || typeof row !== 'object') return null;
  if (cols.length === 1) {
    const v = getValueByPath(row, cols[0]);
    if (v === null || v === undefined) return null;
    return String(v);
  }
  const parts: string[] = [];
  for (const col of cols) {
    const v = getValueByPath(row, col);
    if (v === null || v === undefined) return null;
    parts.push(String(v));
  }
  return parts.join(COMPOSITE_KEY_SEPARATOR);
}
