/**
 * SharedWorkerDataServicesClient — main-thread client. Owns the MessagePort to the
 * SharedWorker (or in-process Hub for tests), routes incoming events
 * to the right per-subscription listener, and exposes a small
 * surface to the rest of the app.
 *
 * Three methods cover everything:
 *   • `attach(providerId, cfg, listener, opts?)` — subscribe to data.
 *     Returns a subId. The first emit is always the cache replace +
 *     current status (Hub guarantees), so the consumer never starts
 *     in an "I haven't seen anything yet" state.
 *   • `attachStats(providerId, listener)` — subscribe to live stats.
 *   • `stop(providerId)` — explicit teardown of the upstream
 *     connection. The Hub does not auto-tear-down.
 *
 * No request/response correlation — attach + detach + stop are all
 * fire-and-forget. The port either delivers events back or it
 * doesn't (in which case `useProviderStream` shows status: 'loading'
 * forever, which surfaces the issue).
 */

import type {
  AppDataAckEvent,
  AppDataDeltaEvent,
  AppDataRequest,
  AppDataSnapshotEvent,
  AttachRequest,
  DetachRequest,
  Event,
  ProviderStats,
  ProviderStatus,
  Request,
  StopRequest,
} from '../protocol.js';
import { isEvent, isAppDataEvent } from '../protocol.js';
import type { ProviderConfig } from '@starui/types';
import { AppDataMirror } from '../mirror/AppDataMirror.js';

/**
 * Gate for hot-path diagnostic logs. Flip to `true` locally when debugging
 * the worker handshake — the per-delta `console.log` measurably hurts CPU
 * at high message rates even with DevTools closed.
 */
const DEBUG = false;

export type SubId = string;

export interface DataListener<T = unknown> {
  onDelta(rows: readonly T[], replace: boolean): void;
  onStatus(status: ProviderStatus, error?: string): void;
}

export interface StatsListener {
  onStats(stats: ProviderStats): void;
}

export interface AttachOpts {
  /**
   * Restart payload. When the provider is already running, the Hub
   * forwards this to `provider.restart(extra)`. Common uses:
   *   - `{ asOfDate: '...' }` for historical mode.
   *   - `{ __refresh: Date.now() }` for a manual refresh.
   */
  extra?: Record<string, unknown>;
}

/**
 * Two-phase subscription handle returned by `client.subscribe(...)`.
 *
 * The two phases match the natural reload-time flow:
 *   1. await `snapshot` — single Promise that resolves with the full
 *      cache (or rejects if the provider can't deliver one).
 *   2. register `onUpdate` — receive live ticks from now on.
 *
 * Updates that arrive between the snapshot resolving and `onUpdate`
 * being registered are buffered, then flushed in order on
 * registration — nothing is silently dropped.
 *
 * `onReset` fires when a `replace: true` delta arrives AFTER the
 * initial snapshot has settled — i.e. the provider re-snapshotted
 * (typically because a peer subscriber clicked "refresh", which
 * makes the worker call `provider.restart` and clears the Hub
 * cache). All connected subscribers receive this signal so every
 * grid wipes + repopulates with the fresh snapshot rather than
 * keeping stale rows on screen.
 */
export interface SubscribeHandle<T = unknown> {
  snapshot: Promise<readonly T[]>;
  onUpdate(cb: (rows: readonly T[]) => void): void;
  onReset(cb: (rows: readonly T[]) => void): void;
  onStatus(cb: (status: ProviderStatus, error?: string) => void): void;
  unsubscribe(): void;
}

interface DataSub {
  kind: 'data';
  listener: DataListener;
}
interface StatsSub {
  kind: 'stats';
  listener: StatsListener;
}
type Sub = DataSub | StatsSub;

export interface SharedWorkerDataServicesClientOpts {
  /** Inject for tests. Default: `() => crypto.randomUUID()`. */
  generateSubId?: () => string;
}

export class SharedWorkerDataServicesClient {
  private readonly port: MessagePort;
  private readonly subs = new Map<SubId, Sub>();
  private readonly generateSubId: () => string;
  private closed = false;

  // ─── AppData (Step 2) ───────────────────────────────────────────
  // The client owns a per-subId map of attached mirrors. Snapshot
  // and delta events are routed by `subId`; ack events route by
  // `reqId` to whichever mirror has that pending request — the
  // mirror tracks its own pending acks, so we just iterate.
  private readonly appDataMirrors = new Map<string, AppDataMirror>();

  constructor(port: MessagePort, opts: SharedWorkerDataServicesClientOpts = {}) {
    this.port = port;
    this.generateSubId = opts.generateSubId ?? (() => crypto.randomUUID());
    this.port.addEventListener('message', this.handleMessage);
    this.port.start();
  }

  // ─── public surface ───────────────────────────────────────────

  attach<T = unknown>(
    providerId: string,
    cfg: ProviderConfig | undefined,
    listener: DataListener<T>,
    opts: AttachOpts = {},
  ): SubId {
    if (this.closed) throw new Error('[SharedWorkerDataServicesClient] client is closed');
    const subId = this.generateSubId();
    this.subs.set(subId, { kind: 'data', listener: listener as DataListener });
    this.send({
      kind: 'attach',
      subId,
      providerId,
      cfg,
      mode: 'data',
      extra: opts.extra,
    });
    return subId;
  }

  /**
   * Two-phase subscription that matches the natural mental model:
   *
   *   1. Reload → connect to (or create) the SharedWorker.
   *   2. Grid requests the snapshot.
   *   3. Worker delivers the snapshot — either from its cache, or by
   *      starting the provider and waiting for its snapshot phase to
   *      complete.
   *   4. Grid applies the snapshot.
   *   5. Grid subscribes for live updates.
   *
   * Returns a handle with:
   *   • `snapshot: Promise<T[]>` — resolves with the full snapshot
   *     once. Awaiting it is step 4 of the flow above.
   *   • `onUpdate(cb)` — registers the live-tick callback. Called only
   *     for post-snapshot updates. If updates arrive between snapshot
   *     resolution and onUpdate registration, they're buffered and
   *     flushed in order on registration.
   *   • `onStatus(cb)` — provider status changes (loading/ready/error).
   *   • `unsubscribe()` — tear down the subscription.
   *
   * Internally this rides the same wire protocol as `attach`: the
   * Hub's first emit is always `{replace: true}` carrying the snapshot,
   * subsequent emits are live deltas. The handle simply unbundles
   * those two phases for the consumer so the snapshot can be awaited
   * and the live-update path doesn't have to also know about
   * `replace: true`.
   */
  subscribe<T = unknown>(
    providerId: string,
    cfg: ProviderConfig | undefined,
    opts: AttachOpts = {},
  ): SubscribeHandle<T> {
    if (this.closed) throw new Error('[SharedWorkerDataServicesClient] client is closed');

    const subId = this.generateSubId();
    if (DEBUG) {
      // eslint-disable-next-line no-console
      console.log(
        `[data-services/client] %csubscribe→worker%c subId=%s provider=%s cfgPassed=%s${opts.extra ? ' extra=' + JSON.stringify(opts.extra) : ''}`,
        'color:#3b82f6', '', subId, providerId, Boolean(cfg),
      );
    }

    let snapshotResolve!: (rows: readonly T[]) => void;
    let snapshotReject!: (err: Error) => void;
    const snapshot = new Promise<readonly T[]>((resolve, reject) => {
      snapshotResolve = resolve;
      snapshotReject = reject;
    });

    let snapshotSettled = false; // true after resolve OR reject
    let updateCb: ((rows: readonly T[]) => void) | null = null;
    let resetCb: ((rows: readonly T[]) => void) | null = null;
    let statusCb: ((status: ProviderStatus, error?: string) => void) | null = null;
    const bufferedUpdates: ReadonlyArray<T>[] = [];
    /** Replace=true deltas that arrived after the snapshot settled but
     *  before the consumer registered `onReset`. Flushed in order on
     *  registration (last one wins for the visible state, but firing
     *  each lets observability hooks see the full sequence). */
    const bufferedResets: ReadonlyArray<T>[] = [];

    // Snapshot is "the cache state at the moment the provider becomes
    // ready". The Hub's wire protocol sends:
    //   1. an immediate replace=true delta on attach carrying whatever
    //      is currently in the cache (possibly empty if the provider
    //      is still in its loading/snapshot phase);
    //   2. one or more `status` events as the provider transitions;
    //   3. on snapshot-end-token, another replace=true delta with the
    //      now-populated cache, followed by `status: 'ready'`.
    //
    // We hold the LATEST replace=true rows in `latestSnapshotRows` and
    // commit-resolve only when the status reaches `ready`. That way:
    //   - subscribing to an already-ready provider resolves on the
    //     first round-trip (delta + status:ready arrive together);
    //   - subscribing to a still-loading provider waits past the
    //     empty initial replay until the real snapshot lands.
    let latestSnapshotRows: readonly T[] | null = null;
    let currentStatus: ProviderStatus | null = null;
    let currentError: string | undefined;

    const flushBuffered = () => {
      if (!updateCb) return;
      while (bufferedUpdates.length > 0) {
        const next = bufferedUpdates.shift()!;
        updateCb(next);
      }
    };

    const trySettleSnapshot = () => {
      if (snapshotSettled) return;
      if (currentStatus === 'error') {
        snapshotSettled = true;
        snapshotReject(new Error(currentError ?? 'Provider error'));
        return;
      }
      if (currentStatus === 'ready' && latestSnapshotRows !== null) {
        snapshotSettled = true;
        snapshotResolve(latestSnapshotRows);
      }
    };

    const listener: DataListener<T> = {
      onDelta: (rows, replace) => {
        if (DEBUG) {
          // eslint-disable-next-line no-console
          console.log(
            `[data-services/client] %cdelta←worker%c subId=%s rows=%d replace=%s settled=%s`,
            replace ? 'color:#10b981' : 'color:#f59e0b', '',
            subId, rows.length, replace, snapshotSettled,
          );
        }
        if (replace) {
          latestSnapshotRows = rows;
          if (snapshotSettled) {
            // Re-snapshot — the provider restarted (worker called
            // provider.restart, cache was cleared and is repopulating).
            // Fire onReset so the consumer wipes + replaces its
            // rendered state. The Promise has already resolved; it
            // can't fire again, but onReset acts as the post-settle
            // equivalent.
            if (resetCb) resetCb(rows);
            else bufferedResets.push(rows);
          } else {
            trySettleSnapshot();
          }
          return;
        }
        // Non-replace delta. Pre-snapshot deltas shouldn't happen
        // under our protocol (the provider buffers during the
        // snapshot phase and emits replace=true at the end), but if
        // they do we queue them rather than dropping. After the
        // snapshot is settled, deltas are live ticks.
        if (updateCb) {
          updateCb(rows);
        } else {
          bufferedUpdates.push(rows);
          if (DEBUG) {
            // eslint-disable-next-line no-console
            console.log(`[data-services/client]   …buffered (no onUpdate handler yet); pending=%d`, bufferedUpdates.length);
          }
        }
      },
      onStatus: (status, error) => {
        if (DEBUG) {
          // eslint-disable-next-line no-console
          console.log(
            `[data-services/client] %cstatus←worker%c subId=%s status=%s%s`,
            'color:#a855f7', '', subId, status, error ? ` error=${JSON.stringify(error)}` : '',
          );
        }
        currentStatus = status;
        currentError = error;
        trySettleSnapshot();
        statusCb?.(status, error);
      },
    };

    this.subs.set(subId, { kind: 'data', listener: listener as DataListener });
    this.send({
      kind: 'attach',
      subId,
      providerId,
      cfg,
      mode: 'data',
      extra: opts.extra,
    });

    return {
      snapshot,
      onUpdate: (cb) => {
        updateCb = cb;
        flushBuffered();
      },
      onReset: (cb) => {
        resetCb = cb;
        while (bufferedResets.length > 0) {
          const rows = bufferedResets.shift()!;
          cb(rows);
        }
      },
      onStatus: (cb) => {
        statusCb = cb;
      },
      unsubscribe: () => {
        if (!this.subs.delete(subId)) return;
        if (this.closed) return;
        this.send({ kind: 'detach', subId });
        // Reject the snapshot promise if it's still pending so awaiters
        // don't hang on unmount.
        if (!snapshotSettled) {
          snapshotSettled = true;
          snapshotReject(new Error('Subscription cancelled before snapshot arrived'));
        }
      },
    };
  }

  attachStats(providerId: string, listener: StatsListener): SubId {
    if (this.closed) throw new Error('[SharedWorkerDataServicesClient] client is closed');
    const subId = this.generateSubId();
    this.subs.set(subId, { kind: 'stats', listener });
    this.send({
      kind: 'attach',
      subId,
      providerId,
      mode: 'stats',
    });
    return subId;
  }

  detach(subId: SubId): void {
    if (!this.subs.delete(subId)) return;
    if (this.closed) return;
    this.send({ kind: 'detach', subId });
  }

  stop(providerId: string): void {
    if (this.closed) return;
    this.send({ kind: 'stop', providerId });
  }

  /**
   * Attach a fresh `AppDataMirror` to the hub. The mirror is a
   * pure RPC client — it sends operations to the hub and receives
   * snapshot/delta events back. The hub owns IndexedDB persistence;
   * the mirror never touches Dexie.
   *
   *   const mirror = client.attachAppData({ userId });
   *   await mirror.attach();
   *   await mirror.ready();
   *   mirror.get('positions', 'asOfDate'); // sync read
   *   await mirror.set('positions', 'asOfDate', '2026-05-08');
   *
   * The caller owns the mirror's lifetime — `client.detachAppData(mirror)`
   * or `client.close()` releases the worker-side listener.
   */
  attachAppData(opts: {
    userId: string;
    /** Override the auto-generated subId (used in tests for determinism). */
    subId?: string;
  }): AppDataMirror {
    const subId = opts.subId ?? this.generateSubId();
    const mirror = new AppDataMirror({
      subId,
      userId: opts.userId,
      send: (req: AppDataRequest) => this.sendAppData(req),
    });
    this.appDataMirrors.set(subId, mirror);
    return mirror;
  }

  /** Detach + remove a previously-attached AppData mirror. */
  detachAppData(mirror: AppDataMirror): void {
    for (const [subId, m] of this.appDataMirrors) {
      if (m === mirror) {
        this.appDataMirrors.delete(subId);
        if (!this.closed) this.sendAppData({ kind: 'appdata-detach', subId });
        return;
      }
    }
  }

  close(): void {
    if (this.closed) return;
    this.closed = true;
    this.subs.clear();
    this.appDataMirrors.clear();
    this.port.removeEventListener('message', this.handleMessage);
    try { this.port.close(); } catch { /* MessagePort.close is fine to call twice */ }
  }

  // ─── internals ────────────────────────────────────────────────

  private send(req: Request | AttachRequest | DetachRequest | StopRequest): void {
    try {
      this.port.postMessage(req);
    } catch (err) {
      // postMessage can throw on dead ports / structured-clone failures.
      // Surface via the affected listener if we can identify it.
      const subId = (req as { subId?: string }).subId;
      if (subId) {
        const sub = this.subs.get(subId);
        if (sub?.kind === 'data') {
          sub.listener.onStatus('error', err instanceof Error ? err.message : String(err));
        }
      }
    }
  }

  private sendAppData(req: AppDataRequest): void {
    if (this.closed) return;
    try {
      this.port.postMessage(req);
    } catch (err) {
      // eslint-disable-next-line no-console
      console.error('[SharedWorkerDataServicesClient] AppData postMessage failed', err);
    }
  }

  private handleMessage = (ev: MessageEvent): void => {
    if (isAppDataEvent(ev.data)) {
      this.routeAppDataEvent(ev.data);
      return;
    }
    if (!isEvent(ev.data)) return;
    const event: Event = ev.data;
    const sub = this.subs.get(event.subId);
    if (!sub) return; // listener detached before this event landed; drop.
    switch (event.kind) {
      case 'delta':
        if (sub.kind === 'data') {
          sub.listener.onDelta(event.rows, Boolean(event.replace));
        }
        return;
      case 'status':
        if (sub.kind === 'data') {
          sub.listener.onStatus(event.status, event.error);
        }
        return;
      case 'stats':
        if (sub.kind === 'stats') {
          sub.listener.onStats(event.stats);
        }
        return;
    }
  };

  private routeAppDataEvent(event: AppDataSnapshotEvent | AppDataDeltaEvent | AppDataAckEvent): void {
    if (event.kind === 'appdata-ack') {
      // Ack events don't carry a subId — every mirror is asked to
      // resolve its pending request matching reqId. Mirrors with no
      // such reqId are no-ops, so this is safe.
      for (const mirror of this.appDataMirrors.values()) mirror.handleEvent(event);
      return;
    }
    const mirror = this.appDataMirrors.get(event.subId);
    if (!mirror) return; // mirror detached before this event landed; drop.
    mirror.handleEvent(event);
  }
}

/**
 * Test helper: build a SharedWorkerDataServicesClient wired to an in-process Hub via a
 * MessageChannel. Saves every consumer from rebuilding this in their
 * own tests.
 *
 * Usage:
 *   const { client } = createInPageWiring(attachPort);
 *   client.attach(...)
 *   ... hub.handleRequest fires ... events stream back to the client
 */
export interface InPageWiring {
  client: SharedWorkerDataServicesClient;
  /** Disconnect both ends. */
  close(): void;
}

export function createInPageWiring(
  attachToHub: (clientPort: MessagePort) => void,
  opts?: SharedWorkerDataServicesClientOpts,
): InPageWiring {
  const channel = new MessageChannel();
  attachToHub(channel.port2);
  const client = new SharedWorkerDataServicesClient(channel.port1, opts);
  return {
    client,
    close: () => {
      client.close();
      try { channel.port2.close(); } catch { /* idempotent */ }
    },
  };
}
